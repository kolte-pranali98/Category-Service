package com.jbk.exception;

public class SomethingWentWrongException extends RuntimeException {

	public SomethingWentWrongException(String msg) {
		super(msg);
	}

}
